"use client"

import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react"
import type { User, AuthState } from "@/types"
import { mockAPI } from "@/lib/mock/api"

interface AuthContextType extends AuthState {
  login: (email: string, password: string, rememberMe?: boolean) => Promise<boolean>
  register: (data: { name: string; email: string; password: string; departmentId?: string; phone?: string }) => Promise<boolean>
  logout: () => void
  updateUser: (user: User) => void
  isAdmin: boolean
  isAssetManager: boolean
  isDepartmentHead: boolean
  isEmployee: boolean
  isTechnician: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  token: null,
  refreshToken: null,
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>(initialState)

  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem("assetflow_token") || sessionStorage.getItem("assetflow_token")
      if (storedToken) {
        try {
          const res = await mockAPI.getCurrentUser()
          if (res.success && res.data) {
            setState({
              user: res.data,
              isAuthenticated: true,
              isLoading: false,
              token: storedToken,
              refreshToken: localStorage.getItem("assetflow_refresh") || null,
            })
          } else {
            setState({ ...initialState, isLoading: false })
          }
        } catch {
          setState({ ...initialState, isLoading: false })
        }
      } else {
        setState({ ...initialState, isLoading: false })
      }
    }
    initAuth()
  }, [])

  const login = useCallback(async (email: string, password: string, rememberMe = false) => {
    setState((prev) => ({ ...prev, isLoading: true }))
    try {
      const res = await mockAPI.login(email, password)
      if (res.success && res.data) {
        const storage = rememberMe ? localStorage : sessionStorage
        storage.setItem("assetflow_token", res.data.token)
        storage.setItem("assetflow_refresh", res.data.refreshToken)
        setState({
          user: res.data.user,
          isAuthenticated: true,
          isLoading: false,
          token: res.data.token,
          refreshToken: res.data.refreshToken,
        })
        return true
      }
      setState((prev) => ({ ...prev, isLoading: false }))
      return false
    } catch {
      setState((prev) => ({ ...prev, isLoading: false }))
      return false
    }
  }, [])

  const register = useCallback(async (data: { name: string; email: string; password: string; departmentId?: string; phone?: string }) => {
    setState((prev) => ({ ...prev, isLoading: true }))
    try {
      const res = await mockAPI.register(data)
      setState((prev) => ({ ...prev, isLoading: false }))
      return res.success
    } catch {
      setState((prev) => ({ ...prev, isLoading: false }))
      return false
    }
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem("assetflow_token")
    localStorage.removeItem("assetflow_refresh")
    sessionStorage.removeItem("assetflow_token")
    sessionStorage.removeItem("assetflow_refresh")
    setState(initialState)
    window.location.href = "/login"
  }, [])

  const updateUser = useCallback((user: User) => {
    setState((prev) => ({ ...prev, user }))
  }, [])

  const isAdmin = state.user?.role === "ADMIN"
  const isAssetManager = state.user?.role === "ASSET_MANAGER"
  const isDepartmentHead = state.user?.role === "DEPARTMENT_HEAD"
  const isEmployee = state.user?.role === "EMPLOYEE"
  const isTechnician = state.user?.role === "TECHNICIAN"

  return (
    <AuthContext.Provider
      value={{
        ...state,
        login,
        register,
        logout,
        updateUser,
        isAdmin,
        isAssetManager,
        isDepartmentHead,
        isEmployee,
        isTechnician,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
