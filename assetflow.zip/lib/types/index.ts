export type UserRole = "admin" | "asset_manager" | "department_head" | "employee";

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: UserRole;
  departmentId?: string;
  department?: Department;
  status: "active" | "inactive";
  createdAt: Date;
  updatedAt: Date;
}

export interface Department {
  id: string;
  name: string;
  headId?: string;
  head?: User;
  parentId?: string;
  parent?: Department;
  status: "active" | "inactive";
  createdAt: Date;
  updatedAt: Date;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  fields?: Record<string, unknown>;
  status: "active" | "inactive";
  createdAt: Date;
  updatedAt: Date;
}

export type AssetStatus = 
  | "available" 
  | "allocated" 
  | "reserved" 
  | "under_maintenance" 
  | "lost" 
  | "retired" 
  | "disposed";

export interface Asset {
  id: string;
  tag: string;
  name: string;
  categoryId: string;
  category?: Category;
  serialNumber?: string;
  acquisitionDate?: Date;
  acquisitionCost?: number;
  condition: "excellent" | "good" | "fair" | "poor";
  location: string;
  status: AssetStatus;
  isBookable: boolean;
  images?: string[];
  documents?: string[];
  notes?: string;
  assignedToId?: string;
  assignedTo?: User;
  departmentId?: string;
  department?: Department;
  expectedReturnDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export type AllocationStatus = "pending" | "approved" | "rejected" | "returned";

export interface Allocation {
  id: string;
  assetId: string;
  asset?: Asset;
  fromUserId?: string;
  fromUser?: User;
  toUserId: string;
  toUser?: User;
  toDepartmentId?: string;
  toDepartment?: Department;
  status: AllocationStatus;
  expectedReturnDate?: Date;
  actualReturnDate?: Date;
  returnCondition?: string;
  returnNotes?: string;
  approvedById?: string;
  approvedBy?: User;
  approvedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export type BookingStatus = "upcoming" | "ongoing" | "completed" | "cancelled";

export interface Booking {
  id: string;
  resourceId: string;
  resource?: Asset;
  userId: string;
  user?: User;
  departmentId?: string;
  department?: Department;
  startTime: Date;
  endTime: Date;
  purpose?: string;
  status: BookingStatus;
  createdAt: Date;
  updatedAt: Date;
}

export type MaintenanceStatus = 
  | "pending" 
  | "approved" 
  | "rejected" 
  | "technician_assigned" 
  | "in_progress" 
  | "resolved";

export interface Maintenance {
  id: string;
  assetId: string;
  asset?: Asset;
  requestedById: string;
  requestedBy?: User;
  description: string;
  priority: "low" | "medium" | "high" | "critical";
  status: MaintenanceStatus;
  photos?: string[];
  technicianId?: string;
  technician?: User;
  approvedById?: string;
  approvedBy?: User;
  approvedAt?: Date;
  resolvedAt?: Date;
  resolutionNotes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export type AuditStatus = "open" | "in_progress" | "completed";

export interface Audit {
  id: string;
  name: string;
  scope: string;
  departmentId?: string;
  department?: Department;
  location?: string;
  startDate: Date;
  endDate?: Date;
  auditors: User[];
  status: AuditStatus;
  discrepancies?: AuditDiscrepancy[];
  createdAt: Date;
  updatedAt: Date;
}

export interface AuditDiscrepancy {
  id: string;
  auditId: string;
  assetId: string;
  asset?: Asset;
  expectedLocation: string;
  actualStatus: "verified" | "missing" | "damaged";
  notes?: string;
  createdAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: "info" | "success" | "warning" | "error";
  read: boolean;
  link?: string;
  createdAt: Date;
}

export interface ActivityLog {
  id: string;
  userId?: string;
  user?: User;
  action: string;
  entityType: string;
  entityId?: string;
  details?: Record<string, unknown>;
  createdAt: Date;
}

export interface DashboardKPI {
  label: string;
  value: number | string;
  change?: number;
  icon: string;
  color: string;
}

export interface ChartData {
  name: string;
  value: number;
  [key: string]: string | number;
}
