import type {
  User, Department, Category, Asset, Allocation, Booking,
  Maintenance, Audit, Notification, ActivityLog
} from "@/lib/types";
import {
  mockUsers, mockDepartments, mockCategories, mockAssets,
  mockAllocations, mockBookings, mockMaintenance, mockAudits,
  mockNotifications, mockActivityLogs
} from "@/lib/mock/data";

// Simulate API delay
const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Users
export async function getUsers(): Promise<User[]> {
  await delay(300);
  return [...mockUsers];
}

export async function getUserById(id: string): Promise<User | undefined> {
  await delay(200);
  return mockUsers.find((u) => u.id === id);
}

export async function createUser(data: Partial<User>): Promise<User> {
  await delay(500);
  const newUser = { ...data, id: String(mockUsers.length + 1), createdAt: new Date(), updatedAt: new Date() } as User;
  mockUsers.push(newUser);
  return newUser;
}

export async function updateUser(id: string, data: Partial<User>): Promise<User> {
  await delay(400);
  const idx = mockUsers.findIndex((u) => u.id === id);
  if (idx === -1) throw new Error("User not found");
  mockUsers[idx] = { ...mockUsers[idx], ...data, updatedAt: new Date() };
  return mockUsers[idx];
}

// Departments
export async function getDepartments(): Promise<Department[]> {
  await delay(300);
  return [...mockDepartments];
}

export async function createDepartment(data: Partial<Department>): Promise<Department> {
  await delay(500);
  const newDept = { ...data, id: String(mockDepartments.length + 1), createdAt: new Date(), updatedAt: new Date() } as Department;
  mockDepartments.push(newDept);
  return newDept;
}

export async function updateDepartment(id: string, data: Partial<Department>): Promise<Department> {
  await delay(400);
  const idx = mockDepartments.findIndex((d) => d.id === id);
  if (idx === -1) throw new Error("Department not found");
  mockDepartments[idx] = { ...mockDepartments[idx], ...data, updatedAt: new Date() };
  return mockDepartments[idx];
}

// Categories
export async function getCategories(): Promise<Category[]> {
  await delay(300);
  return [...mockCategories];
}

export async function createCategory(data: Partial<Category>): Promise<Category> {
  await delay(500);
  const newCat = { ...data, id: String(mockCategories.length + 1), createdAt: new Date(), updatedAt: new Date() } as Category;
  mockCategories.push(newCat);
  return newCat;
}

// Assets
export async function getAssets(): Promise<Asset[]> {
  await delay(400);
  return [...mockAssets];
}

export async function getAssetById(id: string): Promise<Asset | undefined> {
  await delay(200);
  return mockAssets.find((a) => a.id === id);
}

export async function createAsset(data: Partial<Asset>): Promise<Asset> {
  await delay(600);
  const newAsset = { ...data, id: String(mockAssets.length + 1), createdAt: new Date(), updatedAt: new Date() } as Asset;
  mockAssets.push(newAsset);
  return newAsset;
}

export async function updateAsset(id: string, data: Partial<Asset>): Promise<Asset> {
  await delay(400);
  const idx = mockAssets.findIndex((a) => a.id === id);
  if (idx === -1) throw new Error("Asset not found");
  mockAssets[idx] = { ...mockAssets[idx], ...data, updatedAt: new Date() };
  return mockAssets[idx];
}

export async function deleteAsset(id: string): Promise<void> {
  await delay(400);
  const idx = mockAssets.findIndex((a) => a.id === id);
  if (idx !== -1) mockAssets.splice(idx, 1);
}

// Allocations
export async function getAllocations(): Promise<Allocation[]> {
  await delay(300);
  return [...mockAllocations];
}

export async function createAllocation(data: Partial<Allocation>): Promise<Allocation> {
  await delay(500);
  const newAlloc = { ...data, id: String(mockAllocations.length + 1), createdAt: new Date(), updatedAt: new Date() } as Allocation;
  mockAllocations.push(newAlloc);
  return newAlloc;
}

export async function updateAllocation(id: string, data: Partial<Allocation>): Promise<Allocation> {
  await delay(400);
  const idx = mockAllocations.findIndex((a) => a.id === id);
  if (idx === -1) throw new Error("Allocation not found");
  mockAllocations[idx] = { ...mockAllocations[idx], ...data, updatedAt: new Date() };
  return mockAllocations[idx];
}

// Bookings
export async function getBookings(): Promise<Booking[]> {
  await delay(300);
  return [...mockBookings];
}

export async function createBooking(data: Partial<Booking>): Promise<Booking> {
  await delay(500);
  // Check for conflicts
  const conflicts = mockBookings.filter(
    (b) =>
      b.resourceId === data.resourceId &&
      b.status !== "cancelled" &&
      new Date(b.startTime) < new Date(data.endTime!) &&
      new Date(b.endTime) > new Date(data.startTime!)
  );
  if (conflicts.length > 0) throw new Error("Booking conflict detected");

  const newBooking = { ...data, id: String(mockBookings.length + 1), createdAt: new Date(), updatedAt: new Date() } as Booking;
  mockBookings.push(newBooking);
  return newBooking;
}

// Maintenance
export async function getMaintenance(): Promise<Maintenance[]> {
  await delay(300);
  return [...mockMaintenance];
}

export async function createMaintenance(data: Partial<Maintenance>): Promise<Maintenance> {
  await delay(500);
  const newMaint = { ...data, id: String(mockMaintenance.length + 1), createdAt: new Date(), updatedAt: new Date() } as Maintenance;
  mockMaintenance.push(newMaint);
  return newMaint;
}

export async function updateMaintenance(id: string, data: Partial<Maintenance>): Promise<Maintenance> {
  await delay(400);
  const idx = mockMaintenance.findIndex((m) => m.id === id);
  if (idx === -1) throw new Error("Maintenance not found");
  mockMaintenance[idx] = { ...mockMaintenance[idx], ...data, updatedAt: new Date() };
  return mockMaintenance[idx];
}

// Audits
export async function getAudits(): Promise<Audit[]> {
  await delay(300);
  return [...mockAudits];
}

export async function createAudit(data: Partial<Audit>): Promise<Audit> {
  await delay(500);
  const newAudit = { ...data, id: String(mockAudits.length + 1), createdAt: new Date(), updatedAt: new Date() } as Audit;
  mockAudits.push(newAudit);
  return newAudit;
}

// Notifications
export async function getNotifications(userId: string): Promise<Notification[]> {
  await delay(200);
  return mockNotifications.filter((n) => n.userId === userId);
}

export async function markNotificationRead(id: string): Promise<void> {
  await delay(200);
  const idx = mockNotifications.findIndex((n) => n.id === id);
  if (idx !== -1) mockNotifications[idx].read = true;
}

// Activity Logs
export async function getActivityLogs(): Promise<ActivityLog[]> {
  await delay(300);
  return [...mockActivityLogs];
}

// Dashboard KPIs
export async function getDashboardKPIs() {
  await delay(300);
  return {
    totalAssets: mockAssets.length,
    availableAssets: mockAssets.filter((a) => a.status === "available").length,
    allocatedAssets: mockAssets.filter((a) => a.status === "allocated").length,
    underMaintenance: mockAssets.filter((a) => a.status === "under_maintenance").length,
    activeBookings: mockBookings.filter((b) => b.status === "upcoming" || b.status === "ongoing").length,
    pendingTransfers: mockAllocations.filter((a) => a.status === "pending").length,
    upcomingReturns: mockAllocations.filter(
      (a) => a.status === "approved" && a.expectedReturnDate && new Date(a.expectedReturnDate) > new Date()
    ).length,
    overdueReturns: mockAllocations.filter(
      (a) => a.status === "approved" && a.expectedReturnDate && new Date(a.expectedReturnDate) < new Date()
    ).length,
    pendingMaintenance: mockMaintenance.filter((m) => m.status === "pending").length,
    totalDepartments: mockDepartments.filter((d) => d.status === "active").length,
    totalEmployees: mockUsers.filter((u) => u.status === "active").length,
  };
}
