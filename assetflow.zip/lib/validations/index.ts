import { z } from "zod"

// Auth
export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  rememberMe: z.boolean().optional(),
})

export const registerSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string(),
  departmentId: z.string().optional(),
  phone: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
})

export const forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
})

export const resetPasswordSchema = z.object({
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
})

// Department
export const departmentSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100),
  code: z.string().min(2, "Code must be at least 2 characters").max(20),
  description: z.string().optional(),
  headId: z.string().optional(),
  parentId: z.string().optional(),
  status: z.enum(["ACTIVE", "INACTIVE"]).default("ACTIVE"),
})

// Category
export const categorySchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100),
  code: z.string().min(2, "Code must be at least 2 characters").max(20),
  description: z.string().optional(),
  color: z.string().optional(),
  depreciationRate: z.number().min(0).max(100).optional(),
  warrantyPeriod: z.number().min(0).optional(),
})

// Employee/User
export const employeeSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100),
  email: z.string().email("Please enter a valid email address"),
  departmentId: z.string().min(1, "Department is required"),
  role: z.enum(["ADMIN", "ASSET_MANAGER", "DEPARTMENT_HEAD", "EMPLOYEE", "TECHNICIAN"]),
  phone: z.string().optional(),
  status: z.enum(["ACTIVE", "INACTIVE", "PENDING"]).default("ACTIVE"),
})

// Asset
export const assetSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(200),
  description: z.string().optional(),
  categoryId: z.string().min(1, "Category is required"),
  serialNumber: z.string().optional(),
  model: z.string().optional(),
  manufacturer: z.string().optional(),
  acquisitionDate: z.string().optional(),
  acquisitionCost: z.number().min(0).optional(),
  condition: z.enum(["EXCELLENT", "GOOD", "FAIR", "POOR", "DAMAGED"]).default("GOOD"),
  location: z.string().min(1, "Location is required"),
  departmentId: z.string().optional(),
  isBookable: z.boolean().default(false),
  isShared: z.boolean().default(false),
  warrantyExpiry: z.string().optional(),
  purchaseOrder: z.string().optional(),
  supplier: z.string().optional(),
})

// Allocation
export const allocationSchema = z.object({
  assetId: z.string().min(1, "Asset is required"),
  toUserId: z.string().optional(),
  toDepartmentId: z.string().optional(),
  expectedReturnDate: z.string().optional(),
  reason: z.string().optional(),
  notes: z.string().optional(),
}).refine((data) => data.toUserId || data.toDepartmentId, {
  message: "Please select an employee or department",
  path: ["toUserId"],
})

export const transferSchema = z.object({
  assetId: z.string().min(1, "Asset is required"),
  toUserId: z.string().optional(),
  toDepartmentId: z.string().optional(),
  reason: z.string().min(1, "Reason is required"),
  notes: z.string().optional(),
}).refine((data) => data.toUserId || data.toDepartmentId, {
  message: "Please select a recipient",
  path: ["toUserId"],
})

export const returnSchema = z.object({
  allocationId: z.string().min(1, "Allocation is required"),
  returnCondition: z.enum(["EXCELLENT", "GOOD", "FAIR", "POOR", "DAMAGED"]),
  returnNotes: z.string().optional(),
})

// Booking
export const bookingSchema = z.object({
  resourceId: z.string().min(1, "Resource is required"),
  title: z.string().min(2, "Title is required").max(200),
  description: z.string().optional(),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  purpose: z.string().optional(),
  attendees: z.number().min(1).optional(),
}).refine((data) => new Date(data.endTime) > new Date(data.startTime), {
  message: "End time must be after start time",
  path: ["endTime"],
})

// Maintenance
export const maintenanceSchema = z.object({
  assetId: z.string().min(1, "Asset is required"),
  title: z.string().min(2, "Title is required").max(200),
  description: z.string().min(10, "Description must be at least 10 characters"),
  priority: z.enum(["LOW", "MEDIUM", "HIGH", "CRITICAL"]).default("MEDIUM"),
  category: z.string().optional(),
  estimatedCost: z.number().min(0).optional(),
})

// Audit
export const auditCycleSchema = z.object({
  name: z.string().min(2, "Name is required").max(200),
  description: z.string().optional(),
  scope: z.enum(["DEPARTMENT", "LOCATION", "CATEGORY", "FULL"]),
  scopeId: z.string().optional(),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
  auditorIds: z.array(z.string()).min(1, "At least one auditor is required"),
}).refine((data) => new Date(data.endDate) >= new Date(data.startDate), {
  message: "End date must be after start date",
  path: ["endDate"],
})

export const auditVerificationSchema = z.object({
  auditId: z.string().min(1, "Audit is required"),
  assetId: z.string().min(1, "Asset is required"),
  status: z.enum(["VERIFIED", "MISSING", "DAMAGED"]),
  notes: z.string().optional(),
  actualLocation: z.string().optional(),
  actualCondition: z.enum(["EXCELLENT", "GOOD", "FAIR", "POOR", "DAMAGED"]).optional(),
})

// Settings
export const profileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().optional(),
  departmentId: z.string().optional(),
})

export const passwordChangeSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(8, "New password must be at least 8 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
})

export type LoginInput = z.infer<typeof loginSchema>
export type RegisterInput = z.infer<typeof registerSchema>
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>
export type DepartmentInput = z.infer<typeof departmentSchema>
export type CategoryInput = z.infer<typeof categorySchema>
export type EmployeeInput = z.infer<typeof employeeSchema>
export type AssetInput = z.infer<typeof assetSchema>
export type AllocationInput = z.infer<typeof allocationSchema>
export type TransferInput = z.infer<typeof transferSchema>
export type ReturnInput = z.infer<typeof returnSchema>
export type BookingInput = z.infer<typeof bookingSchema>
export type MaintenanceInput = z.infer<typeof maintenanceSchema>
export type AuditCycleInput = z.infer<typeof auditCycleSchema>
export type AuditVerificationInput = z.infer<typeof auditVerificationSchema>
export type ProfileInput = z.infer<typeof profileSchema>
export type PasswordChangeInput = z.infer<typeof passwordChangeSchema>
