"use client"

import type {
  User, Department, AssetCategory, Asset, AllocationRecord,
  Booking, MaintenanceRecord, AuditCycle, Notification,
  ActivityLog, DashboardKPI, FilterParams, PaginatedResponse,
  ApiResponse
} from "@/types"
import {
  mockUsers, mockDepartments, mockCategories, mockAssets,
  mockAllocations, mockBookings, mockMaintenance, mockAuditCycles,
  mockNotifications, mockActivityLogs, mockDashboardKPI
} from "./data"

// Simulate network delay
const delay = (ms: number = 300) => new Promise((resolve) => setTimeout(resolve, ms))

class MockAPI {
  private users = [...mockUsers]
  private departments = [...mockDepartments]
  private categories = [...mockCategories]
  private assets = [...mockAssets]
  private allocations = [...mockAllocations]
  private bookings = [...mockBookings]
  private maintenance = [...mockMaintenance]
  private auditCycles = [...mockAuditCycles]
  private notifications = [...mockNotifications]
  private activityLogs = [...mockActivityLogs]

  // Auth
  async login(email: string, password: string): Promise<ApiResponse<{ user: User; token: string; refreshToken: string }>> {
    await delay()
    const user = this.users.find((u) => u.email === email)
    if (!user || password !== "password123") {
      return { success: false, error: "Invalid email or password" }
    }
    return {
      success: true,
      data: {
        user,
        token: `mock-jwt-token-${user.id}`,
        refreshToken: `mock-refresh-token-${user.id}`,
      },
    }
  }

  async register(data: { name: string; email: string; password: string; departmentId?: string; phone?: string }): Promise<ApiResponse<User>> {
    await delay()
    if (this.users.find((u) => u.email === data.email)) {
      return { success: false, error: "Email already registered" }
    }
    const newUser: User = {
      id: `u${this.users.length + 1}`,
      ...data,
      role: "EMPLOYEE",
      status: "ACTIVE",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.users.push(newUser)
    return { success: true, data: newUser }
  }

  async getCurrentUser(): Promise<ApiResponse<User>> {
    await delay()
    return { success: true, data: this.users[0] }
  }

  // Dashboard
  async getDashboardKPI(): Promise<ApiResponse<DashboardKPI>> {
    await delay()
    return { success: true, data: mockDashboardKPI }
  }

  // Departments
  async getDepartments(params?: FilterParams): Promise<PaginatedResponse<Department>> {
    await delay()
    let data = [...this.departments]
    if (params?.search) {
      const search = params.search.toLowerCase()
      data = data.filter((d) => d.name.toLowerCase().includes(search) || d.code.toLowerCase().includes(search))
    }
    if (params?.status) {
      data = data.filter((d) => d.status === params.status)
    }
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    const end = start + limit
    return {
      data: data.slice(start, end),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  async getDepartment(id: string): Promise<ApiResponse<Department>> {
    await delay()
    const dept = this.departments.find((d) => d.id === id)
    if (!dept) return { success: false, error: "Department not found" }
    return { success: true, data: dept }
  }

  async createDepartment(data: Partial<Department>): Promise<ApiResponse<Department>> {
    await delay()
    const newDept: Department = {
      id: `d${this.departments.length + 1}`,
      ...data,
      status: data.status || "ACTIVE",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      employeeCount: 0,
      assetCount: 0,
    } as Department
    this.departments.push(newDept)
    return { success: true, data: newDept }
  }

  async updateDepartment(id: string, data: Partial<Department>): Promise<ApiResponse<Department>> {
    await delay()
    const index = this.departments.findIndex((d) => d.id === id)
    if (index === -1) return { success: false, error: "Department not found" }
    this.departments[index] = { ...this.departments[index], ...data, updatedAt: new Date().toISOString() }
    return { success: true, data: this.departments[index] }
  }

  async deleteDepartment(id: string): Promise<ApiResponse<void>> {
    await delay()
    this.departments = this.departments.filter((d) => d.id !== id)
    return { success: true }
  }

  // Categories
  async getCategories(params?: FilterParams): Promise<PaginatedResponse<AssetCategory>> {
    await delay()
    let data = [...this.categories]
    if (params?.search) {
      const search = params.search.toLowerCase()
      data = data.filter((c) => c.name.toLowerCase().includes(search) || c.code.toLowerCase().includes(search))
    }
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    return {
      data: data.slice(start, start + limit),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  async createCategory(data: Partial<AssetCategory>): Promise<ApiResponse<AssetCategory>> {
    await delay()
    const newCat: AssetCategory = {
      id: `c${this.categories.length + 1}`,
      ...data,
      status: "ACTIVE",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      assetCount: 0,
    } as AssetCategory
    this.categories.push(newCat)
    return { success: true, data: newCat }
  }

  async updateCategory(id: string, data: Partial<AssetCategory>): Promise<ApiResponse<AssetCategory>> {
    await delay()
    const index = this.categories.findIndex((c) => c.id === id)
    if (index === -1) return { success: false, error: "Category not found" }
    this.categories[index] = { ...this.categories[index], ...data, updatedAt: new Date().toISOString() }
    return { success: true, data: this.categories[index] }
  }

  async deleteCategory(id: string): Promise<ApiResponse<void>> {
    await delay()
    this.categories = this.categories.filter((c) => c.id !== id)
    return { success: true }
  }

  // Users/Employees
  async getUsers(params?: FilterParams): Promise<PaginatedResponse<User>> {
    await delay()
    let data = [...this.users]
    if (params?.search) {
      const search = params.search.toLowerCase()
      data = data.filter((u) => u.name.toLowerCase().includes(search) || u.email.toLowerCase().includes(search))
    }
    if (params?.status) data = data.filter((u) => u.status === params.status)
    if (params?.department) data = data.filter((u) => u.departmentId === params.department)
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    return {
      data: data.slice(start, start + limit),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  async createUser(data: Partial<User>): Promise<ApiResponse<User>> {
    await delay()
    const newUser: User = {
      id: `u${this.users.length + 1}`,
      ...data,
      status: data.status || "ACTIVE",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as User
    this.users.push(newUser)
    return { success: true, data: newUser }
  }

  async updateUser(id: string, data: Partial<User>): Promise<ApiResponse<User>> {
    await delay()
    const index = this.users.findIndex((u) => u.id === id)
    if (index === -1) return { success: false, error: "User not found" }
    this.users[index] = { ...this.users[index], ...data, updatedAt: new Date().toISOString() }
    return { success: true, data: this.users[index] }
  }

  async deleteUser(id: string): Promise<ApiResponse<void>> {
    await delay()
    this.users = this.users.filter((u) => u.id !== id)
    return { success: true }
  }

  // Assets
  async getAssets(params?: FilterParams): Promise<PaginatedResponse<Asset>> {
    await delay()
    let data = [...this.assets]
    if (params?.search) {
      const search = params.search.toLowerCase()
      data = data.filter((a) =>
        a.name.toLowerCase().includes(search) ||
        a.tag.toLowerCase().includes(search) ||
        a.serialNumber?.toLowerCase().includes(search)
      )
    }
    if (params?.status) data = data.filter((a) => a.status === params.status)
    if (params?.category) data = data.filter((a) => a.categoryId === params.category)
    if (params?.department) data = data.filter((a) => a.departmentId === params.department)
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    return {
      data: data.slice(start, start + limit),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  async getAsset(id: string): Promise<ApiResponse<Asset>> {
    await delay()
    const asset = this.assets.find((a) => a.id === id)
    if (!asset) return { success: false, error: "Asset not found" }
    return { success: true, data: asset }
  }

  async createAsset(data: Partial<Asset>): Promise<ApiResponse<Asset>> {
    await delay()
    const newAsset: Asset = {
      id: `a${this.assets.length + 1}`,
      tag: `AF-${String(this.assets.length + 1).padStart(4, '0')}`,
      ...data,
      status: data.status || "AVAILABLE",
      condition: data.condition || "GOOD",
      images: [],
      documents: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as Asset
    this.assets.push(newAsset)
    return { success: true, data: newAsset }
  }

  async updateAsset(id: string, data: Partial<Asset>): Promise<ApiResponse<Asset>> {
    await delay()
    const index = this.assets.findIndex((a) => a.id === id)
    if (index === -1) return { success: false, error: "Asset not found" }
    this.assets[index] = { ...this.assets[index], ...data, updatedAt: new Date().toISOString() }
    return { success: true, data: this.assets[index] }
  }

  async deleteAsset(id: string): Promise<ApiResponse<void>> {
    await delay()
    this.assets = this.assets.filter((a) => a.id !== id)
    return { success: true }
  }

  // Allocations
  async getAllocations(params?: FilterParams): Promise<PaginatedResponse<AllocationRecord>> {
    await delay()
    let data = [...this.allocations]
    if (params?.status) data = data.filter((a) => a.status === params.status)
    if (params?.search) {
      const search = params.search.toLowerCase()
      data = data.filter((a) => {
        const asset = this.assets.find((asset) => asset.id === a.assetId)
        return asset?.name.toLowerCase().includes(search) || asset?.tag.toLowerCase().includes(search)
      })
    }
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    return {
      data: data.slice(start, start + limit),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  async createAllocation(data: Partial<AllocationRecord>): Promise<ApiResponse<AllocationRecord>> {
    await delay()
    const asset = this.assets.find((a) => a.id === data.assetId)
    if (asset && asset.status === "ALLOCATED" && data.type === "ALLOCATION") {
      return { success: false, error: "Asset is already allocated. Please use transfer instead." }
    }
    const newAlloc: AllocationRecord = {
      id: `al${this.allocations.length + 1}`,
      ...data,
      status: "PENDING",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as AllocationRecord
    this.allocations.push(newAlloc)
    if (asset && data.type === "ALLOCATION") {
      asset.status = "ALLOCATED"
      asset.assignedToId = data.toUserId
      asset.departmentId = data.toDepartmentId
      asset.expectedReturnDate = data.expectedReturnDate
    }
    return { success: true, data: newAlloc }
  }

  async approveAllocation(id: string, approverId: string): Promise<ApiResponse<AllocationRecord>> {
    await delay()
    const index = this.allocations.findIndex((a) => a.id === id)
    if (index === -1) return { success: false, error: "Allocation not found" }
    this.allocations[index] = {
      ...this.allocations[index],
      status: "APPROVED",
      approvedById: approverId,
      approvedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    return { success: true, data: this.allocations[index] }
  }

  async rejectAllocation(id: string): Promise<ApiResponse<AllocationRecord>> {
    await delay()
    const index = this.allocations.findIndex((a) => a.id === id)
    if (index === -1) return { success: false, error: "Allocation not found" }
    this.allocations[index] = { ...this.allocations[index], status: "REJECTED", updatedAt: new Date().toISOString() }
    return { success: true, data: this.allocations[index] }
  }

  async completeAllocation(id: string): Promise<ApiResponse<AllocationRecord>> {
    await delay()
    const index = this.allocations.findIndex((a) => a.id === id)
    if (index === -1) return { success: false, error: "Allocation not found" }
    this.allocations[index] = {
      ...this.allocations[index],
      status: "COMPLETED",
      completedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    const asset = this.assets.find((a) => a.id === this.allocations[index].assetId)
    if (asset) {
      asset.status = "AVAILABLE"
      asset.assignedToId = undefined
      asset.expectedReturnDate = undefined
    }
    return { success: true, data: this.allocations[index] }
  }

  // Bookings
  async getBookings(params?: FilterParams): Promise<PaginatedResponse<Booking>> {
    await delay()
    let data = [...this.bookings]
    if (params?.status) data = data.filter((b) => b.status === params.status)
    if (params?.search) {
      const search = params.search.toLowerCase()
      data = data.filter((b) => b.title.toLowerCase().includes(search))
    }
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    return {
      data: data.slice(start, start + limit),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  async createBooking(data: Partial<Booking>): Promise<ApiResponse<Booking>> {
    await delay()
    // Check for conflicts
    const conflicts = this.bookings.filter(
      (b) =>
        b.resourceId === data.resourceId &&
        b.status !== "CANCELLED" &&
        b.id !== data.id &&
        new Date(b.startTime) < new Date(data.endTime!) &&
        new Date(b.endTime) > new Date(data.startTime!)
    )
    if (conflicts.length > 0) {
      return { success: false, error: "This time slot conflicts with an existing booking" }
    }
    const newBooking: Booking = {
      id: `b${this.bookings.length + 1}`,
      ...data,
      status: "UPCOMING",
      approvalStatus: "PENDING",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as Booking
    this.bookings.push(newBooking)
    return { success: true, data: newBooking }
  }

  async cancelBooking(id: string, reason?: string): Promise<ApiResponse<Booking>> {
    await delay()
    const index = this.bookings.findIndex((b) => b.id === id)
    if (index === -1) return { success: false, error: "Booking not found" }
    this.bookings[index] = {
      ...this.bookings[index],
      status: "CANCELLED",
      cancelledAt: new Date().toISOString(),
      cancellationReason: reason,
      updatedAt: new Date().toISOString(),
    }
    return { success: true, data: this.bookings[index] }
  }

  // Maintenance
  async getMaintenance(params?: FilterParams): Promise<PaginatedResponse<MaintenanceRecord>> {
    await delay()
    let data = [...this.maintenance]
    if (params?.status) data = data.filter((m) => m.status === params.status)
    if (params?.search) {
      const search = params.search.toLowerCase()
      data = data.filter((m) => m.title.toLowerCase().includes(search) || m.description.toLowerCase().includes(search))
    }
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    return {
      data: data.slice(start, start + limit),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  async createMaintenance(data: Partial<MaintenanceRecord>): Promise<ApiResponse<MaintenanceRecord>> {
    await delay()
    const newMaint: MaintenanceRecord = {
      id: `m${this.maintenance.length + 1}`,
      ...data,
      status: "PENDING",
      images: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as MaintenanceRecord
    this.maintenance.push(newMaint)
    const asset = this.assets.find((a) => a.id === data.assetId)
    if (asset) {
      asset.status = "UNDER_MAINTENANCE"
    }
    return { success: true, data: newMaint }
  }

  async approveMaintenance(id: string, approverId: string): Promise<ApiResponse<MaintenanceRecord>> {
    await delay()
    const index = this.maintenance.findIndex((m) => m.id === id)
    if (index === -1) return { success: false, error: "Maintenance request not found" }
    this.maintenance[index] = {
      ...this.maintenance[index],
      status: "APPROVED",
      approvedById: approverId,
      approvedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    return { success: true, data: this.maintenance[index] }
  }

  async assignTechnician(id: string, technicianId: string): Promise<ApiResponse<MaintenanceRecord>> {
    await delay()
    const index = this.maintenance.findIndex((m) => m.id === id)
    if (index === -1) return { success: false, error: "Maintenance request not found" }
    this.maintenance[index] = {
      ...this.maintenance[index],
      status: "TECHNICIAN_ASSIGNED",
      technicianId,
      updatedAt: new Date().toISOString(),
    }
    return { success: true, data: this.maintenance[index] }
  }

  async startMaintenance(id: string): Promise<ApiResponse<MaintenanceRecord>> {
    await delay()
    const index = this.maintenance.findIndex((m) => m.id === id)
    if (index === -1) return { success: false, error: "Maintenance request not found" }
    this.maintenance[index] = {
      ...this.maintenance[index],
      status: "IN_PROGRESS",
      startedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    return { success: true, data: this.maintenance[index] }
  }

  async resolveMaintenance(id: string, resolution: string, actualCost?: number): Promise<ApiResponse<MaintenanceRecord>> {
    await delay()
    const index = this.maintenance.findIndex((m) => m.id === id)
    if (index === -1) return { success: false, error: "Maintenance request not found" }
    this.maintenance[index] = {
      ...this.maintenance[index],
      status: "RESOLVED",
      resolution,
      actualCost,
      completedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    const asset = this.assets.find((a) => a.id === this.maintenance[index].assetId)
    if (asset) {
      asset.status = "AVAILABLE"
    }
    return { success: true, data: this.maintenance[index] }
  }

  // Audit
  async getAuditCycles(params?: FilterParams): Promise<PaginatedResponse<AuditCycle>> {
    await delay()
    let data = [...this.auditCycles]
    if (params?.status) data = data.filter((a) => a.status === params.status)
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    return {
      data: data.slice(start, start + limit),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  async createAuditCycle(data: Partial<AuditCycle>): Promise<ApiResponse<AuditCycle>> {
    await delay()
    const newAudit: AuditCycle = {
      id: `ac${this.auditCycles.length + 1}`,
      ...data,
      status: "PLANNED",
      totalAssets: 0,
      verifiedAssets: 0,
      missingAssets: 0,
      damagedAssets: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as AuditCycle
    this.auditCycles.push(newAudit)
    return { success: true, data: newAudit }
  }

  async startAudit(id: string): Promise<ApiResponse<AuditCycle>> {
    await delay()
    const index = this.auditCycles.findIndex((a) => a.id === id)
    if (index === -1) return { success: false, error: "Audit cycle not found" }
    this.auditCycles[index] = { ...this.auditCycles[index], status: "IN_PROGRESS", updatedAt: new Date().toISOString() }
    return { success: true, data: this.auditCycles[index] }
  }

  async closeAudit(id: string): Promise<ApiResponse<AuditCycle>> {
    await delay()
    const index = this.auditCycles.findIndex((a) => a.id === id)
    if (index === -1) return { success: false, error: "Audit cycle not found" }
    this.auditCycles[index] = {
      ...this.auditCycles[index],
      status: "CLOSED",
      closedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    return { success: true, data: this.auditCycles[index] }
  }

  // Notifications
  async getNotifications(userId: string): Promise<ApiResponse<Notification[]>> {
    await delay()
    const data = this.notifications.filter((n) => n.userId === userId)
    return { success: true, data }
  }

  async markNotificationRead(id: string): Promise<ApiResponse<Notification>> {
    await delay()
    const index = this.notifications.findIndex((n) => n.id === id)
    if (index === -1) return { success: false, error: "Notification not found" }
    this.notifications[index] = { ...this.notifications[index], isRead: true, readAt: new Date().toISOString() }
    return { success: true, data: this.notifications[index] }
  }

  async markAllNotificationsRead(userId: string): Promise<ApiResponse<void>> {
    await delay()
    this.notifications = this.notifications.map((n) =>
      n.userId === userId ? { ...n, isRead: true, readAt: new Date().toISOString() } : n
    )
    return { success: true }
  }

  // Activity Logs
  async getActivityLogs(params?: FilterParams): Promise<PaginatedResponse<ActivityLog>> {
    await delay()
    let data = [...this.activityLogs]
    if (params?.search) {
      const search = params.search.toLowerCase()
      data = data.filter((l) => l.action.toLowerCase().includes(search))
    }
    const page = params?.page || 1
    const limit = params?.limit || 10
    const start = (page - 1) * limit
    return {
      data: data.slice(start, start + limit),
      meta: { page, limit, total: data.length, totalPages: Math.ceil(data.length / limit) },
    }
  }

  // Reports data
  async getUtilizationData(): Promise<ApiResponse<{ name: string; value: number }[]>> {
    await delay()
    return {
      success: true,
      data: [
        { name: "Engineering", value: 85 },
        { name: "Facilities", value: 72 },
        { name: "Field Ops", value: 68 },
        { name: "Executive", value: 45 },
        { name: "Marketing", value: 30 },
      ],
    }
  }

  async getMaintenanceTrend(): Promise<ApiResponse<{ date: string; count: number; cost: number }[]>> {
    await delay()
    return {
      success: true,
      data: [
        { date: "Jan", count: 3, cost: 450 },
        { date: "Feb", count: 5, cost: 720 },
        { date: "Mar", count: 2, cost: 280 },
        { date: "Apr", count: 4, cost: 560 },
        { date: "May", count: 6, cost: 890 },
        { date: "Jun", count: 3, cost: 420 },
        { date: "Jul", count: 4, cost: 535 },
      ],
    }
  }

  async getAssetStatusDistribution(): Promise<ApiResponse<{ name: string; value: number }[]>> {
    await delay()
    return {
      success: true,
      data: [
        { name: "Available", value: 42 },
        { name: "Allocated", value: 76 },
        { name: "Under Maintenance", value: 4 },
        { name: "Reserved", value: 3 },
        { name: "Lost", value: 2 },
        { name: "Retired", value: 1 },
      ],
    }
  }

  async getBookingHeatmap(): Promise<ApiResponse<{ day: string; hour: number; value: number }[]>> {
    await delay()
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri"]
    const data: { day: string; hour: number; value: number }[] = []
    days.forEach((day) => {
      for (let hour = 8; hour <= 18; hour++) {
        data.push({
          day,
          hour,
          value: Math.floor(Math.random() * 10),
        })
      }
    })
    return { success: true, data }
  }
}

export const mockAPI = new MockAPI()
