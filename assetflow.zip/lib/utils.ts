import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string | Date, options?: Intl.DateTimeFormatOptions): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    ...options,
  })
}

export function formatDateTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function formatTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function formatCurrency(amount: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount)
}

export function formatNumber(num: number, decimals = 0): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(num)
}

export function formatRelativeTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  const seconds = Math.floor(diff / 1000)
  const minutes = Math.floor(seconds / 60)
  const hours = Math.floor(minutes / 60)
  const days = Math.floor(hours / 24)

  if (seconds < 60) return 'just now'
  if (minutes < 60) return `${minutes}m ago`
  if (hours < 24) return `${hours}h ago`
  if (days < 7) return `${days}d ago`
  return formatDate(d)
}

export function generateAssetTag(index: number): string {
  return `AF-${String(index).padStart(4, '0')}`
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}

export function debounce<T extends (...args: any[]) => void>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: ReturnType<typeof setTimeout>
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId)
    timeoutId = setTimeout(() => fn(...args), delay)
  }
}

export function throttle<T extends (...args: any[]) => void>(
  fn: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle = false
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      fn(...args)
      inThrottle = true
      setTimeout(() => (inThrottle = false), limit)
    }
  }
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    ACTIVE: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    INACTIVE: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
    PENDING: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
    SUSPENDED: 'bg-red-500/10 text-red-600 border-red-500/20',
    AVAILABLE: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    ALLOCATED: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    RESERVED: 'bg-violet-500/10 text-violet-600 border-violet-500/20',
    UNDER_MAINTENANCE: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
    LOST: 'bg-red-500/10 text-red-600 border-red-500/20',
    RETIRED: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
    DISPOSED: 'bg-gray-500/10 text-gray-600 border-gray-500/20',
    APPROVED: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    REJECTED: 'bg-red-500/10 text-red-600 border-red-500/20',
    COMPLETED: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    CANCELLED: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
    UPCOMING: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    ONGOING: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    LOW: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
    MEDIUM: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
    HIGH: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
    CRITICAL: 'bg-red-500/10 text-red-600 border-red-500/20',
    VERIFIED: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    MISSING: 'bg-red-500/10 text-red-600 border-red-500/20',
    DAMAGED: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
    NOT_CHECKED: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
    EXCELLENT: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    GOOD: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    FAIR: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
    POOR: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  }
  return colors[status] || 'bg-slate-500/10 text-slate-600 border-slate-500/20'
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength) + '...'
}

export function downloadFile(content: string, filename: string, type: string) {
  const blob = new Blob([content], { type })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

export function copyToClipboard(text: string): Promise<void> {
  return navigator.clipboard.writeText(text)
}

export function isOverdue(date: string | Date): boolean {
  const d = typeof date === 'string' ? new Date(date) : date
  return d < new Date()
}

export function daysUntil(date: string | Date): number {
  const d = typeof date === 'string' ? new Date(date) : date
  const diff = d.getTime() - Date.now()
  return Math.ceil(diff / (1000 * 60 * 60 * 24))
}
