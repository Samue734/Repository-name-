"use client"

import { useState } from "react"
import { Bell, Check, Trash2, AlertTriangle, Info, CheckCircle2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { mockNotifications } from "@/lib/mock/data"
import { formatRelativeTime } from "@/lib/utils"

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState(mockNotifications)

  const markRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n))
  }

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })))
  }

  const getIcon = (type: string) => {
    if (type.includes("ALERT") || type.includes("OVERDUE")) return <AlertTriangle className="h-4 w-4 text-destructive" />
    if (type.includes("APPROVED") || type.includes("CONFIRMED")) return <CheckCircle2 className="h-4 w-4 text-emerald-500" />
    return <Info className="h-4 w-4 text-blue-500" />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Notifications</h1>
          <p className="text-muted-foreground">Stay updated with system alerts and events</p>
        </div>
        <Button variant="outline" onClick={markAllRead}><Check className="h-4 w-4 mr-2" /> Mark All Read</Button>
      </div>

      <div className="flex gap-2">
        <Badge variant="outline" className="cursor-pointer">All</Badge>
        <Badge variant="outline" className="cursor-pointer">Alerts</Badge>
        <Badge variant="outline" className="cursor-pointer">Approvals</Badge>
        <Badge variant="outline" className="cursor-pointer">Bookings</Badge>
      </div>

      <Card className="card-enterprise"><CardContent className="p-0">
        <div className="divide-y divide-border/50">
          {notifications.map(n => (
            <div key={n.id} className={`flex items-start gap-4 p-4 ${!n.isRead ? "bg-primary/5" : ""}`}>
              <div className="mt-0.5">{getIcon(n.type)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm">{n.title}</p>
                  {!n.isRead && <div className="h-2 w-2 rounded-full bg-primary" />}
                  <Badge variant="outline" className="text-xs ml-auto">{n.priority}</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">{n.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{formatRelativeTime(n.createdAt)}</p>
              </div>
              <div className="flex gap-1">
                {!n.isRead && <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => markRead(n.id)}><Check className="h-3.5 w-3.5" /></Button>}
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent></Card>
    </div>
  )
}
