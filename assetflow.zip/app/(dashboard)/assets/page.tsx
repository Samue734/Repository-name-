"use client"

import { useState } from "react"
import { Package, Plus, Search, Filter, QrCode, Barcode3, Pencil, Trash2, Eye } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { mockAssets, mockCategories, mockDepartments, mockUsers } from "@/lib/mock/data"
import { getStatusColor, getStatusColor as getConditionColor } from "@/lib/utils"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export default function AssetsPage() {
  const [search, setSearch] = useState("")
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null)

  const filteredAssets = mockAssets.filter(a => 
    a.name.toLowerCase().includes(search.toLowerCase()) || 
    a.tag.toLowerCase().includes(search.toLowerCase()) ||
    a.serialNumber?.toLowerCase().includes(search.toLowerCase())
  )

  const asset = selectedAsset ? mockAssets.find(a => a.id === selectedAsset) : null

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Asset Directory</h1>
          <p className="text-muted-foreground">Manage and track all company assets</p>
        </div>
        <Button><Plus className="h-4 w-4 mr-2" /> Register Asset</Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search by tag, name, serial..." className="pl-10" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Button variant="outline"><Filter className="h-4 w-4 mr-2" /> Filters</Button>
      </div>

      <Card className="card-enterprise"><CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tag</TableHead><TableHead>Name</TableHead><TableHead>Category</TableHead>
              <TableHead>Status</TableHead><TableHead>Condition</TableHead><TableHead>Location</TableHead>
              <TableHead>Assigned To</TableHead><TableHead className="w-[120px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAssets.map((a) => (
              <TableRow key={a.id}>
                <TableCell><Badge variant="outline" className="font-mono">{a.tag}</Badge></TableCell>
                <TableCell className="font-medium">{a.name}</TableCell>
                <TableCell>{mockCategories.find(c => c.id === a.categoryId)?.name}</TableCell>
                <TableCell><Badge className={getStatusColor(a.status)}>{a.status.replace("_", " ")}</Badge></TableCell>
                <TableCell><Badge variant="outline" className={getConditionColor(a.condition)}>{a.condition}</Badge></TableCell>
                <TableCell className="text-muted-foreground text-sm">{a.location}</TableCell>
                <TableCell>{a.assignedToId ? mockUsers.find(u => u.id === a.assignedToId)?.name : "-"}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelectedAsset(a.id)}><Eye className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent></Card>

      <Dialog open={!!selectedAsset} onOpenChange={() => setSelectedAsset(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>Asset Details - {asset?.tag}</DialogTitle></DialogHeader>
          {asset && (
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Name</Label><p className="font-medium">{asset.name}</p></div>
              <div><Label>Category</Label><p>{mockCategories.find(c => c.id === asset.categoryId)?.name}</p></div>
              <div><Label>Serial Number</Label><p className="font-mono">{asset.serialNumber || "-"}</p></div>
              <div><Label>Model</Label><p>{asset.model || "-"}</p></div>
              <div><Label>Status</Label><Badge className={getStatusColor(asset.status)}>{asset.status}</Badge></div>
              <div><Label>Condition</Label><Badge variant="outline" className={getConditionColor(asset.condition)}>{asset.condition}</Badge></div>
              <div><Label>Location</Label><p>{asset.location}</p></div>
              <div><Label>Department</Label><p>{mockDepartments.find(d => d.id === asset.departmentId)?.name || "-"}</p></div>
              <div><Label>Acquisition Cost</Label><p className="font-medium">${asset.acquisitionCost?.toLocaleString() || "-"}</p></div>
              <div><Label>Current Value</Label><p className="font-medium">${asset.currentValue?.toLocaleString() || "-"}</p></div>
              <div className="col-span-2"><Label>Description</Label><p className="text-muted-foreground">{asset.description || "-"}</p></div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function Label({ children }: { children: React.ReactNode }) {
  return <p className="text-xs text-muted-foreground mb-1">{children}</p>
}
