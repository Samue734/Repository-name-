"use client"

import { useState } from "react"
import { Activity, Search, Filter } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { mockActivityLogs, mockUsers } from "@/lib/mock/data"
import { formatRelativeTime, getInitials } from "@/lib/utils"

export default function ActivityPage() {
  const [search, setSearch] = useState("")

  const filtered = mockActivityLogs.filter(l => 
    l.action.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Activity Logs</h1>
        <p className="text-muted-foreground">Track all system activities and changes</p>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search activities..." className="pl-10" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <Card className="card-enterprise"><CardContent className="p-6">
        <div className="space-y-4">
          {filtered.map((log, i) => {
            const user = mockUsers.find(u => u.id === log.userId)
            return (
              <div key={log.id} className="flex items-start gap-4 pb-4 border-b border-border/30 last:border-0 last:pb-0">
                <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary shrink-0">
                  {getInitials(user?.name || "U")}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{user?.name}</span>
                    <Badge variant="outline" className="text-xs">{log.action.replace("_", " ")}</Badge>
                    <span className="text-xs text-muted-foreground ml-auto">{formatRelativeTime(log.createdAt)}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {log.entityType}: {Object.values(log.details || {}).join(" ")}
                  </p>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent></Card>
    </div>
  )
}
