"use client"

import { useState } from "react"
import { Building2, Tag, Users, Plus, Search, Pencil, Trash2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { mockDepartments, mockCategories, mockUsers } from "@/lib/mock/data"
import { getStatusColor, getInitials } from "@/lib/utils"

export default function OrganizationPage() {
  const [activeTab, setActiveTab] = useState("departments")
  const [search, setSearch] = useState("")

  const filteredDepartments = mockDepartments.filter(d => d.name.toLowerCase().includes(search.toLowerCase()) || d.code.toLowerCase().includes(search.toLowerCase()))
  const filteredCategories = mockCategories.filter(c => c.name.toLowerCase().includes(search.toLowerCase()))
  const filteredEmployees = mockUsers.filter(u => u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Organization Setup</h1>
        <p className="text-muted-foreground">Manage departments, categories, and employees</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="departments" className="gap-2"><Building2 className="h-4 w-4" /> Departments</TabsTrigger>
          <TabsTrigger value="categories" className="gap-2"><Tag className="h-4 w-4" /> Categories</TabsTrigger>
          <TabsTrigger value="employees" className="gap-2"><Users className="h-4 w-4" /> Employees</TabsTrigger>
        </TabsList>

        <div className="flex items-center gap-4 mt-6 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search..." className="pl-10" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <Button><Plus className="h-4 w-4 mr-2" /> Add {activeTab.slice(0, -1)}</Button>
        </div>

        <TabsContent value="departments" className="mt-0">
          <Card className="card-enterprise"><CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Code</TableHead><TableHead>Head</TableHead><TableHead>Status</TableHead><TableHead>Employees</TableHead><TableHead className="w-[100px]">Actions</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {filteredDepartments.map((dept) => (
                  <TableRow key={dept.id}>
                    <TableCell className="font-medium">{dept.name}</TableCell>
                    <TableCell><Badge variant="outline">{dept.code}</Badge></TableCell>
                    <TableCell>{dept.headId ? mockUsers.find(u => u.id === dept.headId)?.name : "-"}</TableCell>
                    <TableCell><Badge className={getStatusColor(dept.status)}>{dept.status}</Badge></TableCell>
                    <TableCell>{dept.employeeCount}</TableCell>
                    <TableCell><div className="flex gap-1"><Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-3.5 w-3.5" /></Button><Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-3.5 w-3.5" /></Button></div></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="categories" className="mt-0">
          <Card className="card-enterprise"><CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Code</TableHead><TableHead>Assets</TableHead><TableHead>Warranty</TableHead><TableHead>Status</TableHead><TableHead className="w-[100px]">Actions</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {filteredCategories.map((cat) => (
                  <TableRow key={cat.id}>
                    <TableCell className="font-medium flex items-center gap-2"><div className="h-3 w-3 rounded-full" style={{ backgroundColor: cat.color }} />{cat.name}</TableCell>
                    <TableCell><Badge variant="outline">{cat.code}</Badge></TableCell>
                    <TableCell>{cat.assetCount}</TableCell>
                    <TableCell>{cat.warrantyPeriod ? `${cat.warrantyPeriod} months` : "-"}</TableCell>
                    <TableCell><Badge className={getStatusColor(cat.status)}>{cat.status}</Badge></TableCell>
                    <TableCell><div className="flex gap-1"><Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-3.5 w-3.5" /></Button><Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-3.5 w-3.5" /></Button></div></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="employees" className="mt-0">
          <Card className="card-enterprise"><CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Department</TableHead><TableHead>Role</TableHead><TableHead>Status</TableHead><TableHead className="w-[100px]">Actions</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {filteredEmployees.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium"><div className="flex items-center gap-2"><div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary">{getInitials(user.name)}</div>{user.name}</div></TableCell>
                    <TableCell className="text-muted-foreground">{user.email}</TableCell>
                    <TableCell>{mockDepartments.find(d => d.id === user.departmentId)?.name || "-"}</TableCell>
                    <TableCell><Badge variant="outline">{user.role.replace("_", " ")}</Badge></TableCell>
                    <TableCell><Badge className={getStatusColor(user.status)}>{user.status}</Badge></TableCell>
                    <TableCell><Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-3.5 w-3.5" /></Button></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
