"use client"

import { useState } from "react"
import { ClipboardCheck, Plus, Search, Play, Lock, CheckCircle2, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import { mockAuditCycles, mockUsers } from "@/lib/mock/data"
import { getStatusColor, formatDate } from "@/lib/utils"

export default function AuditPage() {
  const [search, setSearch] = useState("")

  const filtered = mockAuditCycles.filter(a => a.name.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Asset Audit</h1>
          <p className="text-muted-foreground">Run structured verification cycles</p>
        </div>
        <Button><Plus className="h-4 w-4 mr-2" /> New Audit Cycle</Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search audit cycles..." className="pl-10" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="grid gap-4">
        {filtered.map(audit => {
          const progress = audit.totalAssets > 0 ? (audit.verifiedAssets / audit.totalAssets) * 100 : 0
          return (
            <Card key={audit.id} className="card-enterprise">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-lg">{audit.name}</h3>
                      <Badge className={getStatusColor(audit.status)}>{audit.status.replace("_", " ")}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{audit.description}</p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mt-2">
                      <span>Scope: {audit.scope}</span>
                      <span>Auditors: {audit.auditorIds.map(id => mockUsers.find(u => u.id === id)?.name).join(", ")}</span>
                      <span>{formatDate(audit.startDate)} - {formatDate(audit.endDate)}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {audit.status === "PLANNED" && <Button size="sm"><Play className="h-4 w-4 mr-1" /> Start</Button>}
                    {audit.status === "IN_PROGRESS" && <Button size="sm"><CheckCircle2 className="h-4 w-4 mr-1" /> Close</Button>}
                    {audit.status === "COMPLETED" && <Button size="sm" variant="outline"><Lock className="h-4 w-4 mr-1" /> Lock</Button>}
                  </div>
                </div>

                <div className="mt-4 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Progress</span>
                    <span className="font-medium">{audit.verifiedAssets} / {audit.totalAssets} verified</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                {audit.missingAssets > 0 && (
                  <div className="mt-4 flex items-center gap-2 p-3 rounded-lg bg-destructive/5 border border-destructive/10">
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                    <span className="text-sm text-destructive font-medium">{audit.missingAssets} assets missing, {audit.damagedAssets} damaged</span>
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
