"use client"

import { useState } from "react"
import { Wrench, Plus, Search, Check, X, UserCheck, Play, CheckCircle2 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { mockMaintenance, mockAssets, mockUsers } from "@/lib/mock/data"
import { getStatusColor, formatDate } from "@/lib/utils"

export default function MaintenancePage() {
  const [search, setSearch] = useState("")

  const filtered = mockMaintenance.filter(m => 
    m.title.toLowerCase().includes(search.toLowerCase()) || 
    m.description.toLowerCase().includes(search.toLowerCase())
  )

  const columns = [
    { id: "PENDING", title: "Pending", color: "bg-amber-500/10 border-amber-500/20" },
    { id: "APPROVED", title: "Approved", color: "bg-blue-500/10 border-blue-500/20" },
    { id: "TECHNICIAN_ASSIGNED", title: "Assigned", color: "bg-violet-500/10 border-violet-500/20" },
    { id: "IN_PROGRESS", title: "In Progress", color: "bg-orange-500/10 border-orange-500/20" },
    { id: "RESOLVED", title: "Resolved", color: "bg-emerald-500/10 border-emerald-500/20" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Maintenance Management</h1>
          <p className="text-muted-foreground">Track and manage maintenance requests</p>
        </div>
        <Button><Plus className="h-4 w-4 mr-2" /> Raise Request</Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search maintenance requests..." className="pl-10" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-5">
        {columns.map(col => {
          const items = filtered.filter(m => m.status === col.id)
          return (
            <Card key={col.id} className={`card-enterprise ${col.color} border`}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  {col.title}
                  <Badge variant="outline" className="text-xs">{items.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {items.map(item => {
                  const asset = mockAssets.find(a => a.id === item.assetId)
                  return (
                    <Card key={item.id} className="bg-background/80 shadow-sm">
                      <CardContent className="p-3 space-y-2">
                        <div className="flex items-center justify-between">
                          <Badge variant="outline" className={getStatusColor(item.priority)}>{item.priority}</Badge>
                          <span className="text-xs text-muted-foreground">{formatDate(item.createdAt)}</span>
                        </div>
                        <p className="text-sm font-medium">{item.title}</p>
                        <p className="text-xs text-muted-foreground">{asset?.name}</p>
                        <p className="text-xs text-muted-foreground">{item.description.slice(0, 60)}...</p>
                        <div className="flex gap-1 pt-1">
                          {item.status === "PENDING" && (
                            <><Button size="sm" variant="outline" className="h-7 text-xs"><Check className="h-3 w-3 mr-1" /> Approve</Button>
                            <Button size="sm" variant="outline" className="h-7 text-xs text-destructive"><X className="h-3 w-3 mr-1" /> Reject</Button></>
                          )}
                          {item.status === "APPROVED" && (
                            <Button size="sm" variant="outline" className="h-7 text-xs"><UserCheck className="h-3 w-3 mr-1" /> Assign</Button>
                          )}
                          {item.status === "TECHNICIAN_ASSIGNED" && (
                            <Button size="sm" variant="outline" className="h-7 text-xs"><Play className="h-3 w-3 mr-1" /> Start</Button>
                          )}
                          {item.status === "IN_PROGRESS" && (
                            <Button size="sm" variant="outline" className="h-7 text-xs"><CheckCircle2 className="h-3 w-3 mr-1" /> Resolve</Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
