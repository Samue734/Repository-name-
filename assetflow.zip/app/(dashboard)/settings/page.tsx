"use client"

import { useState } from "react"
import { Settings, Moon, Sun, Bell, Shield, Globe } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useTheme } from "next-themes"

export default function SettingsPage() {
  const { theme, setTheme } = useTheme()
  const [emailNotif, setEmailNotif] = useState(true)
  const [pushNotif, setPushNotif] = useState(true)
  const [maintenanceAlerts, setMaintenanceAlerts] = useState(true)
  const [overdueAlerts, setOverdueAlerts] = useState(true)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your preferences and system settings</p>
      </div>

      <div className="grid gap-6 max-w-2xl">
        <Card className="card-enterprise">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Sun className="h-5 w-5" /> Appearance</CardTitle>
            <CardDescription>Customize how AssetFlow looks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base">Theme</Label>
                <p className="text-sm text-muted-foreground">Select your preferred theme</p>
              </div>
              <div className="flex gap-2">
                <Button variant={theme === "light" ? "default" : "outline"} size="sm" onClick={() => setTheme("light")}><Sun className="h-4 w-4 mr-1" /> Light</Button>
                <Button variant={theme === "dark" ? "default" : "outline"} size="sm" onClick={() => setTheme("dark")}><Moon className="h-4 w-4 mr-1" /> Dark</Button>
                <Button variant={theme === "system" ? "default" : "outline"} size="sm" onClick={() => setTheme("system")}>System</Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-enterprise">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Bell className="h-5 w-5" /> Notifications</CardTitle>
            <CardDescription>Configure your notification preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div><Label>Email Notifications</Label><p className="text-sm text-muted-foreground">Receive updates via email</p></div>
              <Switch checked={emailNotif} onCheckedChange={setEmailNotif} />
            </div>
            <div className="flex items-center justify-between">
              <div><Label>Push Notifications</Label><p className="text-sm text-muted-foreground">Browser push notifications</p></div>
              <Switch checked={pushNotif} onCheckedChange={setPushNotif} />
            </div>
            <div className="flex items-center justify-between">
              <div><Label>Maintenance Alerts</Label><p className="text-sm text-muted-foreground">Get notified about maintenance</p></div>
              <Switch checked={maintenanceAlerts} onCheckedChange={setMaintenanceAlerts} />
            </div>
            <div className="flex items-center justify-between">
              <div><Label>Overdue Alerts</Label><p className="text-sm text-muted-foreground">Alerts for overdue returns</p></div>
              <Switch checked={overdueAlerts} onCheckedChange={setOverdueAlerts} />
            </div>
          </CardContent>
        </Card>

        <Card className="card-enterprise">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5" /> Security</CardTitle>
            <CardDescription>Manage your account security</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div><Label className="text-base">Two-Factor Authentication</Label><p className="text-sm text-muted-foreground">Add an extra layer of security</p></div>
              <Button variant="outline" size="sm">Enable</Button>
            </div>
            <div className="flex items-center justify-between">
              <div><Label className="text-base">Change Password</Label><p className="text-sm text-muted-foreground">Update your password regularly</p></div>
              <Button variant="outline" size="sm">Change</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
