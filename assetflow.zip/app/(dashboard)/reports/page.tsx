"use client"

import { useEffect, useState } from "react"
import { BarChart3, Download, PieChart, TrendingUp, Activity } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { mockAPI } from "@/lib/mock/api"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RePieChart, Pie, Cell, LineChart, Line, Legend } from "recharts"

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#6b7280"]

export default function ReportsPage() {
  const [utilization, setUtilization] = useState<any[]>([])
  const [maintenanceTrend, setMaintenanceTrend] = useState<any[]>([])
  const [assetStatus, setAssetStatus] = useState<any[]>([])

  useEffect(() => {
    mockAPI.getUtilizationData().then(res => res.success && setUtilization(res.data || []))
    mockAPI.getMaintenanceTrend().then(res => res.success && setMaintenanceTrend(res.data || []))
    mockAPI.getAssetStatusDistribution().then(res => res.success && setAssetStatus(res.data || []))
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports & Analytics</h1>
          <p className="text-muted-foreground">Insights and operational metrics</p>
        </div>
        <Button variant="outline"><Download className="h-4 w-4 mr-2" /> Export</Button>
      </div>

      <Tabs defaultValue="utilization">
        <TabsList>
          <TabsTrigger value="utilization" className="gap-2"><BarChart3 className="h-4 w-4" /> Utilization</TabsTrigger>
          <TabsTrigger value="maintenance" className="gap-2"><TrendingUp className="h-4 w-4" /> Maintenance</TabsTrigger>
          <TabsTrigger value="distribution" className="gap-2"><PieChart className="h-4 w-4" /> Distribution</TabsTrigger>
        </TabsList>

        <TabsContent value="utilization" className="mt-4">
          <Card className="card-enterprise">
            <CardHeader><CardTitle>Department Utilization</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={utilization}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }} />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="mt-4">
          <Card className="card-enterprise">
            <CardHeader><CardTitle>Maintenance Trend</CardTitle></CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={maintenanceTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
                  <YAxis yAxisId="left" stroke="hsl(var(--muted-foreground))" />
                  <YAxis yAxisId="right" orientation="right" stroke="hsl(var(--muted-foreground))" />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }} />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="count" name="Requests" stroke="#3b82f6" strokeWidth={2} dot={{ fill: "#3b82f6" }} />
                  <Line yAxisId="right" type="monotone" dataKey="cost" name="Cost ($)" stroke="#10b981" strokeWidth={2} dot={{ fill: "#10b981" }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="distribution" className="mt-4">
          <Card className="card-enterprise">
            <CardHeader><CardTitle>Asset Status Distribution</CardTitle></CardHeader>
            <CardContent className="flex justify-center">
              <ResponsiveContainer width="100%" height={400}>
                <RePieChart>
                  <Pie data={assetStatus} cx="50%" cy="50%" innerRadius={80} outerRadius={140} paddingAngle={4} dataKey="value" label>
                    {assetStatus.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }} />
                  <Legend />
                </RePieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
