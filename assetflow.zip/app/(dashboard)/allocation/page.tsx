"use client"

import { useState } from "react"
import { ArrowLeftRight, Plus, Search, Check, X, RotateCcw, History } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { mockAllocations, mockAssets, mockUsers, mockDepartments } from "@/lib/mock/data"
import { getStatusColor, formatDate } from "@/lib/utils"

export default function AllocationPage() {
  const [search, setSearch] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  const filtered = mockAllocations.filter(a => {
    const asset = mockAssets.find(asset => asset.id === a.assetId)
    return asset?.name.toLowerCase().includes(search.toLowerCase()) || asset?.tag.toLowerCase().includes(search.toLowerCase())
  }).filter(a => activeTab === "all" ? true : a.status === activeTab.toUpperCase())

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Asset Allocation & Transfer</h1>
          <p className="text-muted-foreground">Manage asset assignments and transfers</p>
        </div>
        <Button><Plus className="h-4 w-4 mr-2" /> New Allocation</Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search allocations..." className="pl-10" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="PENDING">Pending</TabsTrigger>
          <TabsTrigger value="APPROVED">Approved</TabsTrigger>
          <TabsTrigger value="COMPLETED">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-4">
          <Card className="card-enterprise"><CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Asset</TableHead><TableHead>Type</TableHead><TableHead>From</TableHead>
                  <TableHead>To</TableHead><TableHead>Status</TableHead><TableHead>Date</TableHead>
                  <TableHead className="w-[150px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((alloc) => {
                  const asset = mockAssets.find(a => a.id === alloc.assetId)
                  return (
                    <TableRow key={alloc.id}>
                      <TableCell className="font-medium">{asset?.name} <span className="text-muted-foreground text-xs">({asset?.tag})</span></TableCell>
                      <TableCell><Badge variant="outline">{alloc.type}</Badge></TableCell>
                      <TableCell>{alloc.fromUserId ? mockUsers.find(u => u.id === alloc.fromUserId)?.name : mockDepartments.find(d => d.id === alloc.fromDepartmentId)?.name || "-"}</TableCell>
                      <TableCell>{alloc.toUserId ? mockUsers.find(u => u.id === alloc.toUserId)?.name : mockDepartments.find(d => d.id === alloc.toDepartmentId)?.name || "-"}</TableCell>
                      <TableCell><Badge className={getStatusColor(alloc.status)}>{alloc.status}</Badge></TableCell>
                      <TableCell className="text-muted-foreground text-sm">{formatDate(alloc.createdAt)}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {alloc.status === "PENDING" && (
                            <><Button variant="ghost" size="icon" className="h-8 w-8 text-emerald-600"><Check className="h-3.5 w-3.5" /></Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><X className="h-3.5 w-3.5" /></Button></>
                          )}
                          {alloc.status === "APPROVED" && (
                            <Button variant="ghost" size="icon" className="h-8 w-8"><RotateCcw className="h-3.5 w-3.5" /></Button>
                          )}
                          <Button variant="ghost" size="icon" className="h-8 w-8"><History className="h-3.5 w-3.5" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
