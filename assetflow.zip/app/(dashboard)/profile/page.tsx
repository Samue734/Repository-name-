"use client"

import { useState } from "react"
import { User, Mail, Phone, Building2, Shield, Camera } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/contexts/auth-context"
import { getInitials } from "@/lib/utils"
import { mockDepartments } from "@/lib/mock/data"

export default function ProfilePage() {
  const { user } = useAuth()
  const [isEditing, setIsEditing] = useState(false)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Profile</h1>
        <p className="text-muted-foreground">Manage your personal information</p>
      </div>

      <div className="grid gap-6 max-w-2xl">
        <Card className="card-enterprise">
          <CardContent className="p-6">
            <div className="flex items-center gap-6">
              <div className="relative">
                <Avatar className="h-24 w-24">
                  <AvatarFallback className="bg-primary/10 text-primary text-2xl font-semibold">{getInitials(user?.name || "U")}</AvatarFallback>
                </Avatar>
                <Button size="icon" variant="secondary" className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full"><Camera className="h-4 w-4" /></Button>
              </div>
              <div>
                <h2 className="text-xl font-semibold">{user?.name}</h2>
                <p className="text-muted-foreground">{user?.email}</p>
                <div className="flex gap-2 mt-2">
                  <Badge variant="outline">{user?.role?.replace("_", " ")}</Badge>
                  <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">{user?.status}</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-enterprise">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>Your basic profile details</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => setIsEditing(!isEditing)}>{isEditing ? "Cancel" : "Edit"}</Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name"><User className="h-3.5 w-3.5 inline mr-1" /> Full Name</Label>
                <Input id="name" defaultValue={user?.name} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email"><Mail className="h-3.5 w-3.5 inline mr-1" /> Email</Label>
                <Input id="email" type="email" defaultValue={user?.email} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone"><Phone className="h-3.5 w-3.5 inline mr-1" /> Phone</Label>
                <Input id="phone" defaultValue={user?.phone} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="department"><Building2 className="h-3.5 w-3.5 inline mr-1" /> Department</Label>
                <Input id="department" defaultValue={mockDepartments.find(d => d.id === user?.departmentId)?.name} disabled />
              </div>
            </div>
            {isEditing && <Button className="mt-4">Save Changes</Button>}
          </CardContent>
        </Card>

        <Card className="card-enterprise">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5" /> Account Security</CardTitle>
            <CardDescription>Manage your password and security settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div><Label className="text-base">Password</Label><p className="text-sm text-muted-foreground">Last changed 30 days ago</p></div>
              <Button variant="outline" size="sm">Change Password</Button>
            </div>
            <div className="flex items-center justify-between">
              <div><Label className="text-base">Active Sessions</Label><p className="text-sm text-muted-foreground">1 active session</p></div>
              <Button variant="outline" size="sm" className="text-destructive">Logout All</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
