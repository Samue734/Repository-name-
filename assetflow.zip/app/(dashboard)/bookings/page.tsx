"use client"

import { useState } from "react"
import { CalendarDays, Plus, Search, Clock, Check, X, Calendar } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { mockBookings, mockAssets, mockUsers, mockDepartments } from "@/lib/mock/data"
import { getStatusColor, formatDateTime } from "@/lib/utils"

export default function BookingsPage() {
  const [search, setSearch] = useState("")

  const filtered = mockBookings.filter(b => b.title.toLowerCase().includes(search.toLowerCase()))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Resource Booking</h1>
          <p className="text-muted-foreground">Book shared resources and manage schedules</p>
        </div>
        <Button><Plus className="h-4 w-4 mr-2" /> New Booking</Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search bookings..." className="pl-10" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-7">
        {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => (
          <Card key={day} className="card-enterprise p-4 text-center">
            <p className="text-sm font-medium text-muted-foreground">{day}</p>
            <p className="text-2xl font-bold mt-1">{8 + i}</p>
            <p className="text-xs text-muted-foreground">Jul 2026</p>
          </Card>
        ))}
      </div>

      <Card className="card-enterprise"><CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Resource</TableHead><TableHead>Title</TableHead><TableHead>Booked By</TableHead>
              <TableHead>Start Time</TableHead><TableHead>End Time</TableHead><TableHead>Status</TableHead>
              <TableHead className="w-[120px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((booking) => {
              const resource = mockAssets.find(a => a.id === booking.resourceId)
              return (
                <TableRow key={booking.id}>
                  <TableCell className="font-medium">{resource?.name}</TableCell>
                  <TableCell>{booking.title}</TableCell>
                  <TableCell>{mockUsers.find(u => u.id === booking.bookedById)?.name}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{formatDateTime(booking.startTime)}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{formatDateTime(booking.endTime)}</TableCell>
                  <TableCell><Badge className={getStatusColor(booking.status)}>{booking.status}</Badge></TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {booking.status === "UPCOMING" && <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><X className="h-3.5 w-3.5" /></Button>}
                    </div>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  )
}
