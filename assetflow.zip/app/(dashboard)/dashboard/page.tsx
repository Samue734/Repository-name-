"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import {
  Package, Users, Wrench, CalendarDays, ArrowLeftRight,
  Clock, AlertTriangle, Building2, Tag
} from "lucide-react"
import { mockAPI } from "@/lib/mock/api"
import type { DashboardKPI } from "@/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { formatNumber } from "@/lib/utils"
import Link from "next/link"

const containerVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.05 } }
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
}

export default function DashboardPage() {
  const [kpi, setKpi] = useState<DashboardKPI | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    mockAPI.getDashboardKPI().then((res) => {
      if (res.success && res.data) setKpi(res.data)
      setLoading(false)
    })
  }, [])

  if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" /></div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here&apos;s your operational overview.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" asChild><Link href="/assets">Register Asset</Link></Button>
          <Button size="sm" asChild><Link href="/bookings">Book Resource</Link></Button>
        </div>
      </div>

      <motion.div variants={containerVariants} initial="hidden" animate="show" className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <motion.div variants={itemVariants}>
          <Card className="card-enterprise">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Assets</CardTitle>
              <Package className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(kpi?.totalAssets || 0)}</div>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-600 border-emerald-500/20">{kpi?.availableAssets} Available</Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="card-enterprise">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Allocated</CardTitle>
              <Users className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatNumber(kpi?.allocatedAssets || 0)}</div>
              <p className="text-xs text-muted-foreground mt-1">{kpi?.upcomingReturns} upcoming returns</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="card-enterprise">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Maintenance</CardTitle>
              <Wrench className="h-4 w-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpi?.underMaintenance || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">{kpi?.pendingMaintenance} pending requests</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="card-enterprise">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Bookings</CardTitle>
              <CalendarDays className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpi?.activeBookings || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">Resources in use</p>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="card-enterprise md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Alerts & Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {kpi && kpi.overdueReturns > 0 && (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-destructive/5 border border-destructive/10">
                <div className="h-2 w-2 rounded-full bg-destructive animate-pulse" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-destructive">{kpi.overdueReturns} assets overdue for return</p>
                  <p className="text-xs text-muted-foreground">Immediate follow-up required</p>
                </div>
                <Button variant="outline" size="sm" asChild><Link href="/allocation">View</Link></Button>
              </div>
            )}
            {kpi && kpi.pendingTransfers > 0 && (
              <div className="flex items-center gap-3 p-3 rounded-lg bg-amber-500/5 border border-amber-500/10">
                <div className="h-2 w-2 rounded-full bg-amber-500" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-amber-600">{kpi.pendingTransfers} pending transfer requests</p>
                  <p className="text-xs text-muted-foreground">Awaiting approval</p>
                </div>
                <Button variant="outline" size="sm" asChild><Link href="/allocation">Review</Link></Button>
              </div>
            )}
            <div className="flex items-center gap-3 p-3 rounded-lg bg-blue-500/5 border border-blue-500/10">
              <div className="h-2 w-2 rounded-full bg-blue-500" />
              <div className="flex-1">
                <p className="text-sm font-medium text-blue-600">{kpi?.maintenanceToday || 0} maintenance tasks today</p>
                <p className="text-xs text-muted-foreground">Scheduled for completion</p>
              </div>
              <Button variant="outline" size="sm" asChild><Link href="/maintenance">View</Link></Button>
            </div>
          </CardContent>
        </Card>

        <Card className="card-enterprise">
          <CardHeader><CardTitle>Organization</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2"><Building2 className="h-4 w-4 text-muted-foreground" /><span className="text-sm">Departments</span></div>
              <span className="font-semibold">{kpi?.totalDepartments}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2"><Users className="h-4 w-4 text-muted-foreground" /><span className="text-sm">Employees</span></div>
              <span className="font-semibold">{kpi?.totalEmployees}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2"><Tag className="h-4 w-4 text-muted-foreground" /><span className="text-sm">Categories</span></div>
              <span className="font-semibold">{kpi?.totalCategories}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="card-enterprise">
        <CardHeader><CardTitle>Recent Activity</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { action: "Laptop AF-0001 allocated to James Wilson", time: "2 hours ago", type: "allocation" },
              { action: "Conference Room B2 booked for Sprint Planning", time: "4 hours ago", type: "booking" },
              { action: "Maintenance request AF-0055 approved", time: "6 hours ago", type: "maintenance" },
              { action: "Transfer approved: AF-0033 to Facilities dept", time: "8 hours ago", type: "transfer" },
              { action: "Audit discrepancy flagged: AF-0099 damaged", time: "1 day ago", type: "audit" },
            ].map((activity, i) => (
              <div key={i} className="flex items-start gap-3 pb-3 border-b border-border/30 last:border-0 last:pb-0">
                <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                <div className="flex-1">
                  <p className="text-sm">{activity.action}</p>
                  <p className="text-xs text-muted-foreground">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
