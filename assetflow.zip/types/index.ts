// ============================================
// AssetFlow - Enterprise Types
// ============================================

export type UserRole = 'ADMIN' | 'ASSET_MANAGER' | 'DEPARTMENT_HEAD' | 'EMPLOYEE' | 'TECHNICIAN';

export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'PENDING' | 'SUSPENDED';

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: UserRole;
  status: UserStatus;
  departmentId?: string;
  department?: Department;
  phone?: string;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  token: string | null;
  refreshToken: string | null;
}

export type DepartmentStatus = 'ACTIVE' | 'INACTIVE';

export interface Department {
  id: string;
  name: string;
  code: string;
  description?: string;
  headId?: string;
  head?: User;
  parentId?: string;
  parent?: Department;
  children?: Department[];
  status: DepartmentStatus;
  createdAt: string;
  updatedAt: string;
  employeeCount?: number;
  assetCount?: number;
}

export interface AssetCategory {
  id: string;
  name: string;
  code: string;
  description?: string;
  icon?: string;
  color?: string;
  fields?: CategoryField[];
  depreciationRate?: number;
  warrantyPeriod?: number;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  updatedAt: string;
  assetCount?: number;
}

export interface CategoryField {
  id: string;
  name: string;
  type: 'TEXT' | 'NUMBER' | 'DATE' | 'BOOLEAN' | 'SELECT' | 'URL';
  required: boolean;
  options?: string[];
}

export type AssetStatus = 
  | 'AVAILABLE' 
  | 'ALLOCATED' 
  | 'RESERVED' 
  | 'UNDER_MAINTENANCE' 
  | 'LOST' 
  | 'RETIRED' 
  | 'DISPOSED';

export type AssetCondition = 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR' | 'DAMAGED';

export interface Asset {
  id: string;
  tag: string;
  name: string;
  description?: string;
  categoryId: string;
  category?: AssetCategory;
  serialNumber?: string;
  model?: string;
  manufacturer?: string;
  acquisitionDate?: string;
  acquisitionCost?: number;
  currentValue?: number;
  condition: AssetCondition;
  status: AssetStatus;
  location: string;
  departmentId?: string;
  department?: Department;
  assignedToId?: string;
  assignedTo?: User;
  expectedReturnDate?: string;
  isBookable: boolean;
  isShared: boolean;
  qrCode?: string;
  barcode?: string;
  images: string[];
  documents: AssetDocument[];
  specifications?: Record<string, any>;
  warrantyExpiry?: string;
  purchaseOrder?: string;
  supplier?: string;
  createdAt: string;
  updatedAt: string;
  allocationHistory?: AllocationRecord[];
  maintenanceHistory?: MaintenanceRecord[];
}

export interface AssetDocument {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
  uploadedAt: string;
}

export type AllocationType = 'ALLOCATION' | 'TRANSFER' | 'RETURN';

export type AllocationStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED' | 'CANCELLED';

export interface AllocationRecord {
  id: string;
  assetId: string;
  asset?: Asset;
  type: AllocationType;
  fromUserId?: string;
  fromUser?: User;
  toUserId?: string;
  toUser?: User;
  fromDepartmentId?: string;
  fromDepartment?: Department;
  toDepartmentId?: string;
  toDepartment?: Department;
  allocatedById: string;
  allocatedBy?: User;
  approvedById?: string;
  approvedBy?: User;
  status: AllocationStatus;
  expectedReturnDate?: string;
  actualReturnDate?: string;
  returnCondition?: AssetCondition;
  returnNotes?: string;
  reason?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  approvedAt?: string;
  completedAt?: string;
}

export type BookingStatus = 'UPCOMING' | 'ONGOING' | 'COMPLETED' | 'CANCELLED';

export interface Booking {
  id: string;
  resourceId: string;
  resource?: Asset;
  bookedById: string;
  bookedBy?: User;
  departmentId?: string;
  department?: Department;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  status: BookingStatus;
  purpose?: string;
  attendees?: number;
  approvedById?: string;
  approvedBy?: User;
  approvalStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
  updatedAt: string;
  cancelledAt?: string;
  cancellationReason?: string;
}

export type MaintenanceStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'TECHNICIAN_ASSIGNED' | 'IN_PROGRESS' | 'RESOLVED';

export type MaintenancePriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface MaintenanceRecord {
  id: string;
  assetId: string;
  asset?: Asset;
  requestedById: string;
  requestedBy?: User;
  title: string;
  description: string;
  priority: MaintenancePriority;
  status: MaintenanceStatus;
  category?: string;
  estimatedCost?: number;
  actualCost?: number;
  technicianId?: string;
  technician?: User;
  approvedById?: string;
  approvedBy?: User;
  approvedAt?: string;
  startedAt?: string;
  completedAt?: string;
  resolution?: string;
  images: string[];
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type AuditStatus = 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED' | 'CLOSED';

export type VerificationStatus = 'VERIFIED' | 'MISSING' | 'DAMAGED' | 'NOT_CHECKED';

export interface AuditCycle {
  id: string;
  name: string;
  description?: string;
  scope: 'DEPARTMENT' | 'LOCATION' | 'CATEGORY' | 'FULL';
  scopeId?: string;
  scopeName?: string;
  startDate: string;
  endDate: string;
  status: AuditStatus;
  auditors: User[];
  auditorIds: string[];
  createdById: string;
  createdBy?: User;
  totalAssets: number;
  verifiedAssets: number;
  missingAssets: number;
  damagedAssets: number;
  discrepancyReport?: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  closedAt?: string;
}

export interface AuditVerification {
  id: string;
  auditId: string;
  audit?: AuditCycle;
  assetId: string;
  asset?: Asset;
  auditorId: string;
  auditor?: User;
  status: VerificationStatus;
  notes?: string;
  images?: string[];
  expectedLocation: string;
  actualLocation?: string;
  expectedCondition: AssetCondition;
  actualCondition?: AssetCondition;
  verifiedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export type NotificationType = 
  | 'ASSET_ASSIGNED' 
  | 'ASSET_RETURNED' 
  | 'TRANSFER_APPROVED' 
  | 'TRANSFER_REJECTED'
  | 'MAINTENANCE_APPROVED'
  | 'MAINTENANCE_REJECTED'
  | 'MAINTENANCE_RESOLVED'
  | 'BOOKING_CONFIRMED'
  | 'BOOKING_CANCELLED'
  | 'BOOKING_REMINDER'
  | 'OVERDUE_RETURN'
  | 'AUDIT_DISCREPANCY'
  | 'SYSTEM_ALERT'
  | 'DEPARTMENT_UPDATE';

export interface Notification {
  id: string;
  userId: string;
  user?: User;
  type: NotificationType;
  title: string;
  message: string;
  entityId?: string;
  entityType?: string;
  isRead: boolean;
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  createdAt: string;
  readAt?: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  user?: User;
  action: string;
  entityType: string;
  entityId: string;
  details?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

export interface DashboardKPI {
  totalAssets: number;
  availableAssets: number;
  allocatedAssets: number;
  underMaintenance: number;
  activeBookings: number;
  pendingTransfers: number;
  upcomingReturns: number;
  overdueReturns: number;
  maintenanceToday: number;
  pendingMaintenance: number;
  totalDepartments: number;
  totalEmployees: number;
  totalCategories: number;
}

export interface ChartData {
  name: string;
  value: number;
  color?: string;
}

export interface TimeSeriesData {
  date: string;
  value: number;
  category?: string;
}

export interface DepartmentAllocation {
  departmentId: string;
  departmentName: string;
  totalAssets: number;
  allocatedAssets: number;
  utilizationRate: number;
}

export interface HeatmapData {
  day: string;
  hour: number;
  value: number;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  meta?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface PaginatedResponse<T> {
  data: T[];
  meta: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface FilterParams {
  search?: string;
  status?: string;
  category?: string;
  department?: string;
  dateFrom?: string;
  dateTo?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface SidebarItem {
  title: string;
  href: string;
  icon: string;
  badge?: number;
  children?: SidebarItem[];
  roles?: UserRole[];
}

export interface BreadcrumbItem {
  label: string;
  href?: string;
}

export interface CommandItem {
  id: string;
  label: string;
  icon?: string;
  shortcut?: string;
  action: () => void;
  category: string;
}
